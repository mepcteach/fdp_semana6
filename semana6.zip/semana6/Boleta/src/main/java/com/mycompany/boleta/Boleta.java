/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.boleta;

/**
 *
 * @author mpuebla
 */
public class Boleta {
    public static void main(String[] args) {
        // Tamaño de la boleta
        int ancho = 30;
        int alto = 10;
        
        // Dibujar el borde superior
        dibujarLinea(ancho);
        
        // Dibujar el contenido con asteriscos en las esquinas
         for (int i = 0; i < alto - 2; i++) {
            System.out.print("=="); // Borde izquierdo
            for (int j = 0; j < ancho - 4; j++) {
                if (i == 2 && j == 10) {
                    System.out.print("***"); // Un asterisco en medio
                    j += 2; // Para que no sobresalga del ancho
                } else {
                    System.out.print(" "); // Espacio interior
                }
            }
            System.out.println("=="); // Borde derecho
        }
         
        
        
        // Dibujar el borde inferior
         dibujarLinea(ancho);
    }
    
    // Función para dibujar una línea con ==
    public static void dibujarLinea(int ancho) {
        for (int i = 0; i < ancho / 2; i++) {
            System.out.print("==");
        }
        System.out.println();
    }
}

 