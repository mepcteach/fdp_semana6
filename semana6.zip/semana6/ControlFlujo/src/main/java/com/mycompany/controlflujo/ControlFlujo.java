package com.mycompany.controlflujo;



// Clase principal llamada "ControlFlujo"
public class ControlFlujo {
    

    // Método principal donde se ejecuta el programa
    public static void main(String[] args) {
        // Crear una instancia de la clase Persona
        //Persona persona = new Persona("Juan", 25);
        
     
        double valorEntrada = 450.125154;
         
        
        // Usar un método de la clase Persona para imprimir la información de la persona
        persona.mostrarInformacion();

        // Estructura de control condicional if-else
        if (persona.esMayorDeEdad()) {
            System.out.println("La persona es mayor de edad.");
        } else {
            System.out.println("La persona es menor de edad.");
        }

        // Bucle for que imprime los números del 1 al 5
        System.out.println("Números del 1 al 5:");
        for (int i = 1; i <= 5; i++) {
            System.out.println(i);
        }

        // Llamada a una función que calcula la suma de los números de 1 a n
        int resultadoSuma = sumaHastaN(10);
        System.out.println("La suma de los números del 1 al 10 es: " + resultadoSuma);

        // Llamada a una función que usa un bucle while para contar hasta 3
        contarHastaTres();
        
        
        //descuento = valorEntrada - ( valorEntrada * 0.15);
        
        int valorConDescuento = calcularDescuento(valorEntrada);
        
        System.out.println(valorConDescuento);
         
        
    }
    
    
    //Funcion que calcula el descuento
    public static int calcularDescuento (double valorEntrada)
    {
        int descuento =  (int)(valorEntrada - ( valorEntrada * 0.15));
        
        return descuento;
    }
    
    

    // Función que suma los números desde 1 hasta n
    public static int sumaHastaN(int n) {
        int suma = 0; // Variable que acumula la suma
        for (int i = 1; i <= n; i++) {
            suma += i; // Se suma el valor de i a la variable suma
        }
        return suma; // Devuelve el resultado de la suma
    }

    // Función que utiliza un bucle while para contar hasta 3
    public static void contarHastaTres() {
        int contador = 1; // Variable inicial del contador
        while (contador <= 3) {
            System.out.println("Contando: " + contador);
            contador++; // Incrementa el valor del contador en 1
        }
    }
    

    // Clase interna Persona con dos atributos: nombre y edad
    static class Persona {
        // Atributos de la clase Persona
        String nombre;
        int edad;

        // Constructor para inicializar los atributos
        public Persona(String nombre, int edad) {
            this.nombre = nombre;
            this.edad = edad;
        }

        // Método para mostrar la información de la persona
        public void mostrarInformacion() {
            System.out.println("Nombre: " + nombre);
            System.out.println("Edad: " + edad);
        }

        // Método para determinar si la persona es mayor de edad
        public boolean esMayorDeEdad() {
            return edad >= 18; // Devuelve true si la edad es mayor o igual a 18
        }
    }
}
